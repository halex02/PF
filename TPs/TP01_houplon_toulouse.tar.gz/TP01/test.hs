--Question 1 :
somme n = sum [1..n]
